module.exports={
    database:'mongodb://localhost:27017/sensordata',
    secret:'this is my secrete'   
   }